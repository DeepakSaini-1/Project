// Access rock, paper and scissors button
let rock = document.querySelector("#rock");
let paper = document.querySelector("#paper");
let scissors = document.querySelector("#scissors");

// access point bar
let user_p = document.querySelector(".user_p");
let computer_p = document.querySelector(".computer_p");
let user_sco=0;
let comp_sco=0;

// access result bar
let result =  document.querySelector(".result > h2");


function check_win(user, computer){
    console.log(user, computer)
    if(
        user=="rock" && computer=="paper" || //
        user=="scissors" && computer=="rock" || //
        user=="paper" && computer=="scissors" //
        ){
            comp_sco+=1;

            result.style.backgroundColor= "red";
            computer_p.innerText= comp_sco;
            result.innerText= `You lost. ${computer} beats your ${user}`;
    }

    else if(
        computer =="rock" && user=="paper" || //
        computer =="scissors" && user=="rock" || //
        computer =="paper" && user=="scissors"
        ){
            user_sco+=1;
            result.style.backgroundColor= "green";
            user_p.innerText= user_sco;
            result.innerText = `You win! Your ${user} beats ${computer}`;
    } 
    else{
        result.innerText = "Game was Draw. Play again";
        result.style.backgroundColor= "#021c2d";
    }
}

function comp_input(){
    let options = ["rock", "paper", "scissors"]
    let randIdx = Math.floor(Math.random() * 3);
    return options[randIdx];
}

rock.addEventListener("click", (evt) =>{
    check_win("rock",comp_input());
})

paper.addEventListener("click", (evt) =>{
    check_win("paper",comp_input());
})

scissors.addEventListener("click", (evt) =>{
    check_win("scissors",comp_input());
})